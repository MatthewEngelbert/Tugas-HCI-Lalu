let form = document.getElementById("form")
let name = document.getElementById("name")
let email = document.getElementById("email")
let password = document.getElementById("password")
let confirm = document.getElementById("confirm-password")
let dc = document.getElementById("dc")
let yt = document.getElementById("yt")
let terms = document.getElementById("terms")
let error_name = document.getElementById("invalid_name")
let error_email = document.getElementById("invalid_email")
let error_password = document.getElementById("invalid_password")
let error_confirm = document.getElementById("invalid_confirm")
let error_terms = document.getElementById("invalid_terms")

function validate() {
    
    error_name.innerHTML = ""
    error_password.innerHTML = ""
    error_confirm.innerHTML = ""
    error_terms.innerHTML = ""

    if (name.value == ""){
        error_name.innerHTML = "This field cannot be empty."
        return false
    } else if (name.value.length <= 5){
        error_name.innerHTML = "Username must be at least 5 characters long."
        return false
    }

    if (!email_validate(email.value)){
        return false
    }

    if (password.value == ""){
        error_password.innerHTML = "This field cannot be empty."
        return false
    } 
    
    if (password.value.length <= 7){
        error_password.innerHTML = "Password must be at least 8 characters long."
        return false
    }

    if (password.value != confirm.value){
        error_confirm.innerHTML = "Password didn't match"
        return false
    }

    if (!terms.checked){
        error_terms.innerHTML = "You must agree to the Terms and Conditions"
        return false
    }
    
    alert("Thank you for registering!")
    form.submit()

}

function email_validate(email){
    let error_email = document.getElementById("invalid_email")

    error_email.innerHTML = ""

    let count = 0;

    for(let i = 0; i < email.length ; i++)
    if(email[i] == '@'){
        count = 1
    }

    if(email == ""){
        error_email.innerHTML = "This field cannot be empty"
        return false
    }else if(count != 1 || email.length < 6){
        error_email.innerHTML = "Must be a valid e-mail"
        return false
    }

    return true
}
